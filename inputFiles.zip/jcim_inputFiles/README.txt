############# README ##################

Supporting files for "Deciphering binding site conformational variability of substrate promiscuous and specialist enzymes"

Here you can find sample configuration file ("sample_prodRun.conf"), parameter file ("par_all36_prot.prm") and following input files for all the enzymes discussed in the manuscript under their respective folders (named after their respective PDB ids):

1. topology file ("ionised.psf")
2. coordinates file ("*.pdb")
